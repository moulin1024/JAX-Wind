# Single 80 m turbine AD-BEM case

This case contains one turbine at the horizontal centre of an
`8192 x 8192 x 1024 m` domain with a `512 x 512 x 256` mesh.

- Rotor diameter: 80 m
- Hub height: 90 m
- Rotor speed: 16.7 RPM
- Turbine centre: `(4096, 4096, 90) m`
- Rotor smoothing width: 16 m
- Nacelle/tower smoothing width: 16 m
- Model: `openfast-ad-bem`
- Azimuthal smearing elements: 64

The blade chord, twist, lift and drag data were converted from the four XLSX
files supplied in `~/Desktop`. The generated rigid OpenFAST-compatible entry
point is `CustomRotor.fst`.

The HITSZ fitted friction velocity (`u*=0.1229413268 m/s`) and roughness length,
numerical defaults, time step, and workflow durations are inherited from
`cases/HITSZWindTunnel/fv_workflow.toml`. The initial log-law profile is
regenerated on this case's 256 vertical cell centres. The pressure acceleration
is scaled as `u*^2 / 1024 m` so the inherited friction velocity remains
consistent with the taller domain. Review these temporary values before a
production run because they were not specified with the turbine data.

From the JAX-Wind repository root:

```bash
export JAXWIND_SINGLE_80M_FAST="$PWD/cases/test/SingleTurbine80mADBEM/CustomRotor.fst"
jaxwind check cases/test/SingleTurbine80mADBEM/fv_workflow.toml
jaxwind workflow cases/test/SingleTurbine80mADBEM/fv_workflow.toml
```
